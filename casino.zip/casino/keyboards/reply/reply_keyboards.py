from aiogram.types import ReplyKeyboardMarkup
from aiogram.types import CallbackQuery, InputFile, Message
from aiogram.utils.callback_data import CallbackData

def main_menu_keyboard():
  keyboard = ReplyKeyboardMarkup(resize_keyboard=True, row_width=3)
  keyboard.row("🀄 Baccara", "🃏 21 очко")
  keyboard.row("💎 Джек Пот", "🎰 Слоты", "🎲 Все игры")
  keyboard.row("🖥 Кабинет", "👥 Реф. система", "ℹ️ Информация")
  return keyboard



def play_slots_keyboard(bet):
    keyboard = ReplyKeyboardMarkup(resize_keyboard=True)
    keyboard.row(f"📍 Крутить | Ставка: {bet}")
    keyboard.row("🔁 Изменить ставку", "⏪ Выход")
    return keyboard


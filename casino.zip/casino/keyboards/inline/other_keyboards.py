from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from config import config


def cabinet_keyboard():
    keyboard = InlineKeyboardMarkup()
    button1 = InlineKeyboardButton(text="📥Пополнить📥", callback_data="deposit")
    button2 = InlineKeyboardButton(text="📤Вывести📤", callback_data="output")
    keyboard.row(button1, button2)

    return keyboard


def deposit_keyboard():
    keyboard = InlineKeyboardMarkup()
    button2 = InlineKeyboardButton(text="🥝Qiwi/🅿️Payyer", callback_data="qiwi_method_balance")
    button3 = InlineKeyboardButton(
        text="💳Visa (Укр.)", url=f"https://t.me/{config('support_username')}")
    button1 = InlineKeyboardButton(text="₿ Banker", callback_data="deposit:banker")
    keyboard.row(button3,button2)

    return keyboard


def output_keyboard():
    keyboard = InlineKeyboardMarkup()
    button1 = InlineKeyboardButton(text="🥝Qiwi/🅿️Payyer", callback_data="output:qiwi")
    button2 = InlineKeyboardButton(text="₿ Banker", callback_data="output:banker")
    button3 = InlineKeyboardButton(text="❌ Отмена", callback_data="output:cancel")
    keyboard.row(button1, button2)
    keyboard.row(button3)

    return keyboard

def p2p_deposit_keyboard(bill_id, url):
    keyboard = InlineKeyboardMarkup(row_width=2)
    keyboard.add(
        InlineKeyboardButton(text='💸 Оплатить 💸', url=url))
    keyboard.add(
        InlineKeyboardButton(text='🔁 Проверить платёж', callback_data=f'check_p2p_deposit:{bill_id}'),
        InlineKeyboardButton(text='❌ Отменить', callback_data=f'reject_p2p_payment')
        )
    return keyboard


async def check_menu(cost, user_id):
    markup = InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(text="↗️Перейти к оплате", url=f"https://qiwi.com/payment/form/99?"
                                                                    f"extra%5B%27account%27%5D="
                                                                    f"{config('QIWI_ADDRESS')}&amountInteger="
                                                                    f"{cost}&amountFraction=0&"
                                                                    f"extra%5B%27comment%27%5D="
                                                                    f"{user_id}&currency=643&blocked[0]=account&"
                                                                    f"blocked[1]=comment&blocked[2]=sum")
            ],
            [
                InlineKeyboardButton(text="✅Проверить оплату", callback_data="check")
            ],
            [
                InlineKeyboardButton(text="⬅️Назад", callback_data="back_to_main_menu")
            ]
        ]
    )
    return markup


back_to_main_menu = InlineKeyboardMarkup(
    inline_keyboard=[
        [
            InlineKeyboardButton(text="⬅️Назад", callback_data="back_to_personal_account")
        ]
    ]
)

chat_button = InlineKeyboardMarkup(
  inline_keyboard=[
    [
      InlineKeyboardButton(text="🧑‍💻 Админ", url="https://t.me/Karisto_admin"),
      InlineKeyboardButton(text="🤖 Заказать 🤖", url="https://t.me/Karisto_Shop"),
      InlineKeyboardButton(text="💬 Чат", url="https://t.me/CASINO_KKA_CHAT")
      ]
   ]
)

def djevhdh_keyboard():

    keyboard = InlineKeyboardMarkup(row_width=1)

    button99 = InlineKeyboardButton(text="💎 Джек Пот")
    keyboard.add(button99)
    return keyboard
from aiogram.types import Message, InputFile

from config import cabinet_photo, config
from data.functions.db import get_user, get_all_user_refs
from filters.filters import IsPrivate
from keyboards.inline.other_keyboards import cabinet_keyboard, chat_button
from loader import dp, bot
from texts import cabinet_text


@dp.message_handler(IsPrivate(), text="🖥 Кабинет")
async def game_menu(message: Message):
    if get_user(message.chat.id) != None:
        await message.answer(cabinet_text(get_user(message.chat.id)),
                             reply_markup=cabinet_keyboard())


@dp.message_handler(IsPrivate(), text="ℹ️ Информация")
async def chat(message: Message):
    await message.answer("<b><i>ℹ️ Информация о боте \n❗В новостном канале  (https://t.me/Casino_KKA) будут конкурсы и отзывы</i></b>", reply_markup=chat_button)

@dp.message_handler(IsPrivate(), text="🎴 DURAK,POKER")
async def help(message: Message):
    await message.answer("""
<b><i>Для игры в Дурака или Покер:\n
ИГРЫ ЧЕРЕЗ ПРИЛОЖЕНИЕ ДУРАК ОНЛАЙН И PPPoker\n
1️⃣Найдите соперника в чате,убедитесь что он тоже внёс депозит
2️⃣Договоритесь о правилах игры
3️⃣Победитель кидает скриншот в чат или админу и он делает выплату\n
📛Игры на честном слове запрещены!</i></b>""", reply_markup=support_button, parse_mode="HTML")



@dp.message_handler(IsPrivate(), text="👥 Реф. система")
async def referals_handler(message: Message):
    me = await bot.get_me()
    await message.answer(
        f"👥 <b>Приглашай своих друзей и получай {config('ref_percent')}%"
        " от суммы их пополнения, разрешено регистрироваться по своей собственной реф. ссылике, можно накручивать, я не запрещаю до того момента пока не будет награда на баланс сразу</b>\n----------------------------------------------------------------\n🔗 Ваша реферальная ссылка ⤵️"
        f"\nhttps://t.me/{me.username}?start={message.from_user.id}"
        f"\n----------------------------------------------------------------\n🫂 Вы привели {len(get_all_user_refs(message.from_user.id))} рефералов",
        parse_mode="HTML")

from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup
from keyboards.inline.callback_datas import admin_search_user_callback


def djevhdh_keyboard():

    keyboard = InlineKeyboardMarkup(row_width=2)

    button1 = InlineKeyboardButton(text="💎 ДжекПот")
    keyboard.add(butt)
    return keyboard
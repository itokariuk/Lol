﻿import re
import time
import asyncio
import aiohttp

from config import config
from loader import bot
from data.functions.db import get_user, update_balance



async def send_safe(user_id, message):

    try:
      await bot.send_message(
        chat_id=user_id, text=message,
        parse_mode='html', disable_web_page_preview=True)
    except:
      pass


async def send_admins(message):

    for x in config("admin_id").split(":"):
      await send_safe(x, message)


class QiwiAPI(object):

    def __init__(self):
        self.wallet = config('qiwi_address')
        self.token = config('qiwi_token')


    async def GetHistory(self, rows_num, operation_type):

      try:
        async with aiohttp.ClientSession() as session:

          session.headers['authorization'] = f'Bearer {self.token}'
          parameters = {'rows': rows_num,
                        'operation': operation_type,
                        'sources': ['QW_RUB']}
          url = f'https://edge.qiwi.com/payment-history/v2/persons/+{self.wallet}/payments'

          async with session.get(url, params=parameters) as resp:
            return {'status': True, 'data': await resp.json()}

      except Exception as e:
        print(f'Error [utils.QiwiAPI.GetHistory] {e}')
        return {'status': False, 'data': e}
    


    async def CheckTtrans(self):

        lastTxnID, start_check = [], False
        print('QIWI History checked start')
        while self.wallet != '0':

          try:

            history = await self.GetHistory(50, 'IN')
            if history.get('status'):
              history = history.get('data')
            else:
              raise NameError(history.get('data'))

            for x in history.get("data") or []:

              if start_check and x.get("txnId") not in lastTxnID \
                and x.get("comment") and x.get("status") == 'SUCCESS':

                if re.search(r'^g\d*$', x.get("comment", "").lower().strip()):

                  user_id = int(re.findall(r'\d*$', x.get("comment", "").strip())[0])
                  amount = x['sum']['amount']
                  user = get_user(user_id)
                  if user:

                    update_balance(user_id, amount)
                    await send_safe(user_id,
                      f'Выш баланс пополнен на {round(amount, 2)} RUB через QIWI')
                    await send_admins(
                      f'Пользователь <a href="tg://user?id={user_id}">{user_id}</a>'
                      f' пополнен на {round(amount, 2)} RUB через QIWI')
                    if user[5]:
                      ref_pay = amount * (float(config('ref_percent')) / 100)
                      update_balance(user[5], ref_pay)
                      await send_safe(user[5],
                      f'Выш баланс пополнен на {round(ref_pay, 2)} RUB за пополнение вашего реферала')

              if x.get("txnId") not in lastTxnID and x.get("status") == 'SUCCESS':
                lastTxnID.append(x.get("txnId"))

            start_check = True
          except Exception as e:
            print(f'QIWI check:\n{e}')
          await asyncio.sleep(30)